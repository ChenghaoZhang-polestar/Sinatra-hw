Part 0: Demystifying SaaS app creation
==============================

**Goal:** Understand the steps needed to create, version, and deploy a SaaS app, including tracking the libraries it depends on so that your production and development environments are as similar as possible.

**What you will do:** Create a simple "hello world" app using the Sinatra framework, version it properly, and deploy it to Heroku.

Creating and versioning a simple SaaS app
-----------------------------------------

SaaS apps are developed on your computer but *deployed to production* on a server that others can access.  We try to minimize the differences between the development and production *environments*, to avoid difficult-to-diagnose problems in which something works one way on your development computer but a different way (or not at all) when that code is deployed to production.

We have two mechanisms for keeping the development and production environments consistent.  The first is *version control*, such as Git, for the app's code.  But since almost all apps also rely on *libraries* written by others, such as *gems* in the case of Ruby, we need a way to keep track of which versions of which libraries our app has been tested with, so that the same ones are used in development and production.

Happily, Ruby has a wonderful system for managing gem dependencies: a gem called **Bundler** looks for a file called `Gemfile` in the *app root directory* of each project.  The `Gemfile` contains a list of gems and versions your app depends on. Bundler verifies that those gems, and any others that they in turn depend on, are properly installed on your system and accessible to the app.

Let's start with the following steps:

* Create a new empty directory to hold your new app, and use `git init` in that directory to start versioning it with Git.
？？这里是要求用git init把git变成可以管理的仓库，首先要先把git下载好，打开git bash中按指令做好
* In that directory, create a new file called `Gemfile` (the capitalization is important) with the following contents.  This file will be a permanent part of your app and will travel with your app anywhere it goes:

```rb
source 'https://rubygems.org'
ruby '2.6.6'

gem 'sinatra', '>= 2.0.1'
```

The first line says that the preferred place to download any necessary gems is https://rubygems.org, which is where the Ruby community registers "production ready" gems.

The second line specifies which version of the Ruby language interpreter is required.  If we omitted this line, Bundler wouldn't try to verify which version of Ruby is available; there are subtle differences between the versions, and not all gems work with all versions, so it's best to specify this.

The last line says we need version 2.0.1 or later of the `sinatra` gem. In some cases we don't need to specify which version of a gem we want; in this case we do specify it because we rely on some features that are absent from earlier versions of Sinatra.

Run Bundler
-----------

Run the command `bundle`, which examines your `Gemfile` to make sure the correct gems (and, where specified, the correct versions) are available, and tries to install them otherwise.  This will create a new file `Gemfile.lock`, *which you should place under version control.*
？？这里run是在哪里跑？
To place under version control, use these commands:

```sh
$ git add . 添加当前目录下的所有文件到暂存区：
$ git commit -m "Set up the Gemfile"
```
？？先输入git init，在输入add的时候，bash突然开始下载很多东西，输入commit之前要求我的邮箱号，输入邮箱号之后显示invalid key，输入用户名之后成功

The first command stages all changed files for committing. The second command commits the staged files with the comment in the quotes. You can repeat these commands to commit future changes. Remember that these are LOCAL commits -- if you want these changes on GitHub, you'll need to do a git push command, which we will show later.

#### Self Check Questions (click triangle to check your answer)

<details>
  <summary>What's the difference between the purpose and contents of <code>Gemfile</code> and <code>Gemfile.lock</code>?  Which file is needed to completely reproduce the development environment's gems in the production environment?</summary>
  <p><blockquote><code>Gemfile</code> specifies the gems you need and in some cases the constraints on which version(s) are acceptable. <code>Gemfile.lock</code> records the *actual* versions found, not only of the gems you specified explicitly but also any other gems on which they depend, so it is the file used by the production environment to reproduce the gems available in the development environment.</blockquote></p>
</details>
<br />
<details>
  <summary>After running <code>bundle</code>, why are there gems listed in <code>Gemfile.lock</code>
that were not listed in <code>Gemfile</code>?</summary>
  <p><blockquote>Bundler looked up the information for each Gem you requested (in this case, only <code>sinatra</code>) and realized that it depends on other gems, which in turn depend on still others, so it recursively installed all those dependencies.  For example, the <code>rack</code> appserver is a gem, and while you didn't explicitly request it, <code>sinatra</code> depends on it.  This is an example of the power of automation: rather than requiring you (the app developer) to understand every Gem dependency, Bundler automates that process and lets you focus only on your app's top-level dependencies.</blockquote></p>
</details>


Create a simple SaaS app with Sinatra
-------------------------------------

As Chapter 2 of ESaaS explains, SaaS apps require a web server to receive HTTP requests from the outside world, and an application server that "connects" your app's logic to the web server.  For development, we will use `webrick`, a very simple Ruby-based web server that would be inappropriate for production but is fine for development.  In both development and production, we will use the `rack` Ruby-based application server, which supports Ruby apps written in various frameworks including Sinatra and Rails.
正如ESaaS的第二章所解释的，SaaS应用程序需要一个网络服务器来接收来自外部世界的HTTP请求，以及一个将应用程序逻辑“连接”到网络服务器的应用服务器。
对于开发，我们将使用' webrick '，一个非常简单的基于ruby的web服务器，它不适合生产，但适合开发。
在开发和生产中，我们将使用基于Ruby的“rack”应用服务器，它支持用各种框架编写的Ruby应用程序，包括Sinatra和Rails。
As Chapter 2 of *ESaaS* explains, a SaaS app essentially recognizes and responds to HTTP requests corresponding to the application's *routes* (recall that a route consists of an HTTP method such as `GET` or `POST` plus a URI).  Sinatra provides an extremely lightweight shorthand for matching a route with the app code to be executed when a request using that route arrives from the Web server.
正如*ESaaS*的第二章解释的那样，SaaS应用程序本质上识别并响应与应用程序的*路由*对应的HTTP请求(回想一下，路由由一个HTTP方法组成，比如“GET”或“POST”加上一个URI)。Sinatra提供了一种非常轻量级的简写方式，用于在使用该路由的请求从Web服务器到达时，将路由与要执行的应用程序代码进行匹配。
Create a file in your project called `app.rb` containing the following:
？？我试着在我创建的.git工程中新建文档写入以下程序
```rb
require 'sinatra'

class MyApp < Sinatra::Base
  get '/' do
    "<!DOCTYPE html><html><head></head><body><h1>Hello World</h1></body></html>"
  end
end
```

The `get` method is provided by the `Sinatra::Base` class, from which our `MyApp` class inherits; `Sinatra::Base` is available because we load the Sinatra library on line 1.

#### Self Check Question

<details>
  <summary>What *two* steps did we take earlier to guarantee that the Sinatra library is available to load in line 1?</summary>
  <p><blockquote> We specified <code>gem 'sinatra'</code> in the <code>Gemfile</code> *and* successfully ran <code>bundle</code> to confirm that the gem is installed and "lock" the correct version of it in <code>Gemfile.lock</code>.</blockquote></p>
</details>

<br />

As you see from the above simple example, Sinatra lets you write functions that match an incoming HTTP route, in this case `GET '/'` (the root URL), a very simple HTML document containing the string `Hello World` will be returned to the presentation tier as the result of the request.
正如您从上面的简单示例中看到的，Sinatra允许您编写匹配传入HTTP路由的函数，在本例中是' GET '/' '(根URL)，一个包含字符串' Hello World '的非常简单的HTML文档将作为请求的结果返回到表示层。
To run our app, we have to start the application server and presentation tier (web) server.  The `rack` application server is controlled by a file `config.ru`, which you must now create and add to version control, containing the following:
要运行我们的应用程序，我们必须启动应用服务器和表示层(web)服务器。' rack '应用服务器由一个文件' config.ru '控制，您现在必须创建并添加到版本控制中，包含以下内容:
？？很多东西不知道该在哪一级目录中创建
```rb
require './app'
run MyApp
```

The first line tells Rack that our app lives in the file `app.rb`, which you created above to hold your app's code.  We have to explicitly state that our `app` file is located in the current directory (.) because `require` normally looks only in standard system directories to find gems.
第一行告诉Rack我们的应用程序位于文件' app.Rb '中，它是你在上面创建的，用来保存你的应用程序代码。我们必须明确声明我们的' app '文件位于当前目录(.)，因为' require '通常只在标准系统目录中查找gems。
You're now ready to test-drive our simple app with a command line:
| Local computer | Codio |
|-----|------|
| `bundle exec rackup --port 3000` | `bundle exec rackup --host 0.0.0.0 --port 3000` |
？？敲这一行程序提示我 不是内部或外部命令，也不是可运行的程序
This command starts the Rack appserver and the WEBrick webserver.  Prefixing it with `bundle exec` ensures that you are running with the gems specified in `Gemfile.lock`.  Rack will look for `config.ru` and attempt to start our app based on the information there.
？？不知道这行命令在哪输入。
此命令启动Rack appserver和WEBrick webserver。在它前面加上' bundle exec '可以确保你在运行' Gemfile.lock '中指定的gems。rack将寻找' config.ru '，并尝试启动我们的应用程序基于那里的信息。
To see the webapp:

| Local computer | Codio |
|-----|------|
| Visit `localhost:3000` in your browser to see the webapp. It will open in a new tab in the IDE if you click on it, but you should open up a fresh browser tab and paste in that URL. <br><br> Point a new Web browser tab at the running app's URL and verify that you can see "Hello World". | Click the "Box URL" button on your top tool bar. The button should be pre-configured to point at port 3000: <br> <br> ![BoxURL](https://global.codio.com/content/BoxURL.png) <br> <br> The app should open in a new tab. Verify that you can see "Hello World". |

#### Self Check Question

<details>
  <summary>What happens if you try to visit a non-root URL such as <code>https://localhost:3000/hello</code> and why? (your URL root will vary)</summary>
  <p><blockquote> You'll get a humorous error message from the Sinatra framework, since you don't have a route matching <code>get '/hello'</code> in your app.  Since Sinatra is a SaaS framework, the error message is packaged up in a Web page and delivered to your browser.</blockquote></p>
</details>

<br />

You should now have the following files under version control: `Gemfile`, `Gemfile.lock`, `app.rb`, `config.ru`.  This is a minimal SaaS app: the app file itself, the list of explicitly required gems, the list of actual gems installed including the dependencies implied by the required gems, and a configuration file telling the appserver how to start the app.
你现在应该有以下文件在版本控制下:`Gemfile`, `Gemfile.lock`, `app.rb`, `config.ru`。这是一个最小的SaaS应用程序:应用程序文件本身、显式所需gem列表、实际安装的gem列表(包括所需gem隐含的依赖项)，以及一个告诉appserver如何启动应用程序的配置文件。


Modify the app
--------------

Modify `app.rb` so that instead of "Hello World" it prints "Goodbye World". Save your changes to `app.rb` and try refreshing your browser tab where the app is running.
修改应用程序。这样，它输出的就不是“Hello World”，而是“Goodbye World”。保存您的更改到' app。Rb '，并尝试刷新您的浏览器标签，该应用程序正在运行。

No changes? Confused?

Now go back to the shell window where you ran `rackup` and press Ctrl-C to stop Rack.  Then type `bundle exec rackup --port 3000` for local development or `$bundle exec rackup --host 0.0.0.0 --port 3000` for Codio development again, and once it is running, go back to your browser tab with your app and refresh the page.  This time it should work.
现在回到运行' rackup '的shell窗口，按Ctrl-C停止Rack。然后输入“bundle exec rackup——port 3000”进行本地开发，或再次输入“$bundle exec rackup——host 0.0.0.0——port 3000”进行Codio开发，一旦它运行，返回浏览器标签页并刷新页面。这次应该能成功。

What this shows you is that if you modify your app while it's running, you have to restart Rack in order for it to "see" those changes.  Since restarting it manually is tedious, we'll use the `rerun` gem, which restarts Rack automatically when it sees changes to files in the app's directory. (Rails does this for you by default during development, as we'll see, but Sinatra doesn't.)
这表明，如果你在运行时修改应用程序，你必须重新启动Rack才能“看到”这些变化。由于手动重新启动它是乏味的，我们将使用' rerun ' gem，它会在看到应用程序目录中的文件变化时自动重新启动Rack。(正如我们将看到的，Rails在开发过程中为您默认做到了这一点，但Sinatra没有。)

You're probably already thinking: "Aha! If our app depends on this additional gem, we should add it to the Gemfile and run bundle to make sure it's really present." Good thinking. But it may also occur to you that this particular gem wouldn't be necessary in a production environment: we only need it as a tool while developing. Fortunately, there's a way to tell Bundler that some gems are only necessary in certain environments. Add the following to the Gemfile (it doesn't matter where):
你可能已经在想:“啊哈!如果我们的应用依赖于这个额外的gem，我们应该将它添加到Gemfile并运行bundle，以确保它真的存在。”好想法。但是您也可能会想到，这个特定的gem在生产环境中是不必要的:我们只需要它作为开发时的工具。幸运的是，有一种方法可以告诉Bundler某些gem只在特定环境中是必需的。在Gemfile中添加以下内容(在哪里并不重要):

```rb
group :development do
  gem 'rerun'
end
```

Now run `bundle install` to have it download the `rerun` gem and any dependencies, if they aren't already in place.

Any gem specifications inside the `group :development` block will only be examined if bundle is run in the development environment.  (The other environments you can specify are :test and :production, and you can define new environments yourself.)  Gem specifications outside of any group block are assumed to apply in all environments.
只有当bundle在开发环境中运行时，“group:development”块中的任何gem规范才会被检查。(您可以指定的其他环境是:test和:production，并且您可以自己定义新的环境。)任何组块之外的Gem规范都被假定适用于所有环境。
Say the following in the terminal window to start your app and verify the app is running:
| Local computer | Codio |
|-----|------|
| `bundle exec rerun -- rackup --port 3000` | `bundle exec rerun -- rackup -p 3000 -o 0.0.0.0` |

There are more details on rerun's usage available in the gem's [GitHub
README](https://github.com/alexch/rerun#usage). Gems are usually on
GitHub and their READMEs are usually full of helpful instructions about how to use them.

In this case we are prefixing with `bundle exec` again in order to ensure we are using the gems in the Gemfile.lock, and the `--` symbol is there to assert that the command we want rerun to operate with is `rackup -p $PORT -o $IP`.  We could achieve the same effect with `bundle exec rerun "rackup -p 3000 -o 0.0.0.0"`.  They are equivalent.   More importantly, any detected changes will now cause the server to restart automatically, similar to the use of `guard` to auto re-run specs when files change.
在这种情况下，我们再次以' bundle exec '作为前缀，以确保我们在Gemfile中使用gem。'——'符号表示要重新运行的命令是' rackup -p $PORT -o $IP '。
我们可以用' bundle exec rerun "rackup -p 3000 -o 0.0.0.0" '实现同样的效果。他们是等价的。更重要的是，任何检测到的更改将导致服务器自动重启，类似于使用' guard '自动重新运行规格时，文件更改。

Modify `app.rb` to print a different message, and verify that the change is detected by refreshing your browser tab with the running app.  Also before we move on you should commit your latest changes to git.
修改'app.rb '打印一个不同的消息，并通过运行应用程序刷新您的浏览器选项卡来验证更改是否检测到。此外，在我们继续之前，您应该提交您的最新更改到git。

Deploy to Heroku
----------------
Heroku is a cloud platform-as-a-service (PaaS) where we can deploy our Sinatra (and later Rails) applications. If you don't have an account yet, go sign up at http://www.heroku.com. You'll need your login and password for the next step.
Heroku是一个云平台即服务(PaaS)，我们可以在这里部署Sinatra(以及稍后的Rails)应用程序。如果你还没有账户，可以去http://www.heroku.com注册。
下一步需要您的登录名和密码。

Install Heroku CLI following [instructions](https://devcenter.heroku.com/articles/heroku-cli).

Log in to your Heroku account by typing the command: `heroku login -i` in the terminal. This will connect you to your Heroku account.

While in the root directory of your project (not your whole workspace), type `heroku create` to create a new project in Heroku. This will tell the Heroku service to prepare for some incoming code, and locally it will add a remote git repository for you called `heroku`.
在项目的根目录下(不是整个工作区)，输入' heroku create '在heroku中创建一个新项目。这将告诉Heroku服务准备一些传入代码，并在本地为你添加一个名为“Heroku”的远程git存储库。

Next, make sure you stage and commit all changes locally as instructed above (i.e. `git add`, `git commit`, etc).

Earlier we saw that to run the app locally you run `rackup` to start the Rack appserver, and Rack looks in `config.ru` to determine how to start your Sinatra app.  How do you tell a production environment how to start an appserver or other processes necessary to receive requests and start your app?  In the case of Heroku, this is done with a special file named `Procfile`,  which specifies one or more types of Heroku processes your app will use, and how to start each one. The most basic Heroku process type is called a Dyno, or "web worker".  One Dyno can serve one user request at a time.  Since we're on Heroku's free tier, we can only have one Dyno. Let's create a file named `Procfile`, and only this as the name (i.e. Procfile.txt is not valid). Write the following line in your `Procfile`:
早些时候我们发现本地运行的应用程序运行的rackup架appserver开始,齿条看起来“config.ru”来确定如何开始你的Sinatra程序。你如何告诉生产环境中如何启动一个应用服务器或其他流程需要接收请求并开始应用程序吗?在Heroku的例子中，这是通过一个名为“Procfile”的特殊文件完成的，该文件指定应用程序将使用的一种或多种Heroku进程类型，以及如何启动每个进程。最基本的Heroku进程类型被称为Dyno，或“web worker”。一个Dyno一次可以服务一个用户请求。因为我们在Heroku的免费层，所以我们只能有一个Dyno。让我们创建一个名为“Procfile”的文件，名称仅为这个(即Procfile.txt无效)。在你的“Procfile”中写以下一行:
```
web: bundle exec rackup config.ru -p $PORT
```

This tells Heroku to start a single web worker (Dyno) using essentially the same command line you used to start Rack locally. Note that in some cases, a `Procfile` is not necessary since Heroku can infer from your files how to start the app. However, it's always better to be explicit.
这告诉Heroku使用与本地启动Rack相同的命令行启动一个web worker (Dyno)。注意，在某些情况下，' Procfile '是不必要的，因为Heroku可以从你的文件中推断出如何启动应用程序。然而，最好是显式的。

Your local repo is now ready to deploy to Heroku:

```
$ git push heroku master
```

(`master` refers to which branch of the remote Heroku repo we are pushing to.  We'll learn about branches later in the course, but for now, suffice it to say that you can only deploy to the `master` branch on Heroku.) This push will create a running instance of your app at some URL ending with `herokuapp.com`. Enter that URL in a new browser tab to see your app running live. Congratulations, you did it--your app is live!

Summary
-------

* You started a new application project by creating a `Gemfile` specifying which gems you need and running `bundle` to verify that they're available and create the `Gemfile.lock` file that records the versions of gems actually in use.

* You created a Sinatra app in the file `app.rb`, pointed Rack at this file in `config.ru`, and used `rackup` to start the appserver and the WEBrick web server.

* You learned that changing the app's code doesn't automatically cause Rack to reload the app. To save the work of restarting the app manually every time you make a change, you used the `rerun` gem, adding it to the Gemfile in a way that specifies you won't need it in production, only during development.

* You versioned the important files containing not only your app's code but the necessary info to reproduce all the libraries it relies on and the file that starts up the app.

* You deployed this simple app to Heroku.
*你启动一个新的应用程序项目，创建一个“Gemfile”，指定你需要gem，并运行“bundle”，以验证它们是可用的，并创建“Gemfile”。
'文件，记录实际使用的gem版本。

*你在app文件中创建了一个Sinatra应用。在' config.ru '中指向这个文件，并使用' rackup '来启动appserver和WEBrick web服务器。

*你知道改变应用程序的代码并不会自动导致架重新加载应用程序。为了节省手动重新启动应用程序的工作每次你做出改变,你使用了“rerun”gem,将它添加到Gemfile的方式指定你不会需要它在生产中,只有在发展。

*你对重要文件进行了版本控制，其中不仅包含应用程序的代码，还包含复制应用程序所依赖的所有库和启动应用程序的文件所需的信息。

*你在Heroku上部署了这个简单的应用。
-----

Next: [Part 1 - Wordguesser](part_1_wordguesser.md)
